# app/models/inspection_model.py
from sqlalchemy import Column
from sqlalchemy.dialects.sqlite import JSON
from ..extensions import db


class PerformanceInspection(db.Model):
    __tablename__ = "performance_inspection"

    id = db.Column(db.Integer, primary_key=True)

    # Sale.performance_number 를 FK로 참조 (1:1 보장 위해 unique)
    performance_number = db.Column(
        db.String(50),
        db.ForeignKey("sale.performance_number", ondelete="CASCADE"),
        nullable=False,
        unique=True,
        index=True,
    )

    # 이미지 파일이 1~2장이라면 ["url1", "url2"] 형태의 배열로 저장
    images = db.Column(JSON, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "performance_number": self.performance_number,
            "images": self.images,
        }
