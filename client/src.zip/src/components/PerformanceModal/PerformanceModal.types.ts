export interface PerformanceModalState {
    isOpen: boolean;
}
