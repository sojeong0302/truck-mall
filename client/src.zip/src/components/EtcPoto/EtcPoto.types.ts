export interface EtcPotoProps {
    initialImages?: string[];
    setImages?: (images: string[]) => void;
}
