export interface SnsProps {
    className?: string;
    children: React.ReactNode;
    onClick?: () => void;
}
