"use client";

export default function IntroPage() {
    return (
        <div>
            <img src="/images/intro.png" alt="회사소개" />
        </div>
    );
}
