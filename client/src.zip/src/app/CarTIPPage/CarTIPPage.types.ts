export interface CarTIPProps {}
