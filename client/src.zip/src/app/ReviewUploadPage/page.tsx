"use client";
import WritingUpload from "@/components/WritingUpload";

export default function ReviewUploadPage() {
    return (
        <div className="w-full h-full">
            <WritingUpload url="ReviewPage" />
        </div>
    );
}
