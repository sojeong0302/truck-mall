"use client";
import WritingUpload from "@/components/WritingUpload";

export default function CarTIPUploadPage() {
    return (
        <div className="w-full h-full">
            <WritingUpload url="CarTIPPage" />
        </div>
    );
}
