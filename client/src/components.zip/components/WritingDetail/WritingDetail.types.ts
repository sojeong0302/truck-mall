// components/WritingDetail.types.ts

export interface WritingDetailProps {
    id: string;
}
