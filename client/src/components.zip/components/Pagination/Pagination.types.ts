export interface PaginationProps {
    totalPages: number;
}
