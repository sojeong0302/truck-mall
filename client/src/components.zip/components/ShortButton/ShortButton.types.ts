export interface ShortButtonProps {
    className?: string;
    children: React.ReactNode;
    onClick?: () => void;
}
