"use client";
import { useRouter } from "next/navigation";
import ShortButton from "../ShortButton";
import { useModalStore } from "@/store/ModalStateStroe";

export default function Modal({ text, url, onConfirm }: { text: string; url?: string; onConfirm?: () => void }) {
    const router = useRouter();
    const store = useModalStore();
    const { setIsModalOpen, setIsSaleCompleteModalOpen } = store;
    const handleYes = () => {
        setIsModalOpen(false);
        requestAnimationFrame(() => {
            console.log("[Modal] YES clicked");
            if (onConfirm) {
                onConfirm();
            } else if (url) {
                router.push(url);
            }
        });
    };

    const handleNo = () => {
        setIsModalOpen(false);
        setIsSaleCompleteModalOpen(false);
    };

    return (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
            <div className="border-5 border-[#2E7D32] flex flex-col items-center p-5 sm:p-10 bg-white rounded-xl shadow-lg min-w-[300px] max-w-[90%]">
                <img className="w-10 sm:w-20" src="/images/warning.png" alt="경고" />
                <div className="text-center text-base sm:text-xl font-medium p-5 whitespace-pre-line">{text}</div>
                <div className="flex gap-3">
                    <ShortButton onClick={handleYes} className="bg-[#2E7D32] text-white">
                        네
                    </ShortButton>
                    <ShortButton onClick={handleNo} className="bg-gray-200">
                        아니요
                    </ShortButton>
                </div>
            </div>
        </div>
    );
}
